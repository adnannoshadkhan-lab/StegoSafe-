'use strict';

/*
 * StegoSafe payload format (all offsets are byte offsets):
 *   0..3  ASCII magic "SSAF"
 *   4     format version (1)
 *   5     flags: bit 0 = encrypted
 *   6..9  payload byte length, unsigned big-endian uint32
 *   10..  payload bytes
 *
 * Header and payload bytes are encoded MSB-first into RGB LSBs, skipping alpha.
 * Encrypted payload is UTF-8 JSON: {"v":1,"kdf":"PBKDF2-SHA-256","iter":310000,
 * "cipher":"AES-256-GCM","salt":"base64","iv":"base64","ct":"base64"}.
 */

const MAGIC = [0x53, 0x53, 0x41, 0x46]; // "SSAF"
const FORMAT_VERSION = 1;
const HEADER_BYTES = 10;
const MAX_IMAGE_PIXELS = 24_000_000;
const PBKDF2_ITERATIONS = 310_000;
const $ = (id) => document.getElementById(id);

const state = {
  cover: null,
  coverImage: null,
  extract: null,
  extractImage: null,
  outputUrl: null
};

function setStatus(id, message, type = 'info') {
  const el = $(id);
  el.textContent = message;
  el.className = `status ${type}`;
  el.hidden = !message;
}

function clearStatus(id) {
  const el = $(id);
  el.textContent = '';
  el.hidden = true;
  el.className = 'status';
}

function setBusy(button, busy, label) {
  if (busy) {
    button.dataset.originalLabel = button.innerHTML;
    button.disabled = true;
    button.innerHTML = `<span class="loading-spinner" aria-hidden="true"></span> ${label}`;
  } else {
    button.disabled = false;
    if (button.dataset.originalLabel) button.innerHTML = button.dataset.originalLabel;
  }
}

function formatBytes(bytes) {
  if (bytes < 1024) return `${bytes} B`;
  if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(1)} KB`;
  return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function allowedImage(file) {
  return file && ['image/png', 'image/jpeg', 'image/webp', 'image/bmp'].includes(file.type);
}

function loadImageFile(file) {
  return new Promise((resolve, reject) => {
    if (!file || !allowedImage(file)) {
      reject(new Error('Choose a valid PNG, JPEG, WEBP, or BMP image file.'));
      return;
    }
    const url = URL.createObjectURL(file);
    const image = new Image();
    image.onload = () => {
      URL.revokeObjectURL(url);
      const width = image.naturalWidth;
      const height = image.naturalHeight;
      if (!width || !height || width * height > MAX_IMAGE_PIXELS) {
        reject(new Error('This image is too large for safe browser processing. Choose an image with at most 24 million pixels.'));
        return;
      }
      resolve({ file, image, width, height, previewUrl: URL.createObjectURL(file) });
    };
    image.onerror = () => {
      URL.revokeObjectURL(url);
      reject(new Error('The selected file could not be decoded as an image.'));
    };
    image.src = url;
  });
}

function canvasFor(imageDataSource) {
  const canvas = document.createElement('canvas');
  canvas.width = imageDataSource.width;
  canvas.height = imageDataSource.height;
  const context = canvas.getContext('2d', { willReadFrequently: true });
  if (!context) throw new Error('Canvas is unavailable in this browser.');
  context.drawImage(imageDataSource.image, 0, 0);
  return { canvas, context, imageData: context.getImageData(0, 0, canvas.width, canvas.height) };
}

function maxPayloadBytes(width, height) {
  return Math.max(0, Math.floor((width * height * 3) / 8) - HEADER_BYTES);
}

function updateCapacity() {
  const label = $('capacity-label');
  const bar = $('capacity-bar');
  const help = $('capacity-help');
  if (!state.cover) {
    label.textContent = 'Waiting for image';
    bar.style.width = '0%';
    help.textContent = 'Choose an image to estimate how much data it can hold.';
    return;
  }
  const bytes = maxPayloadBytes(state.cover.width, state.cover.height);
  label.textContent = `${formatBytes(bytes)} max`;
  bar.style.width = `${Math.min(100, Math.max(0, bytes / (1024 * 1024) * 100))}%`;
  help.textContent = `${state.cover.width.toLocaleString()} × ${state.cover.height.toLocaleString()} px · approximately ${formatBytes(bytes)} available for payload data, after the ${HEADER_BYTES}-byte header.`;
}

function showPreview(prefix, data) {
  $(`${prefix}-preview`).src = data.previewUrl;
  $(`${prefix}-name`).textContent = data.file.name;
  $(`${prefix}-dimensions`).textContent = `${data.width} × ${data.height} px · ${formatBytes(data.file.size)}`;
  $(`${prefix}-preview-card`).hidden = false;
  $(`${prefix}-drop`).hidden = true;
}

function resetCover() {
  if (state.cover?.previewUrl) URL.revokeObjectURL(state.cover.previewUrl);
  state.cover = null;
  state.coverImage = null;
  $('cover-file').value = '';
  $('cover-preview-card').hidden = true;
  $('cover-drop').hidden = false;
  $('cover-preview').removeAttribute('src');
  $('output-card').hidden = true;
  $('hide-empty').hidden = false;
  if (state.outputUrl) URL.revokeObjectURL(state.outputUrl);
  state.outputUrl = null;
  clearStatus('hide-status');
  updateCapacity();
}

function resetExtractImage() {
  if (state.extract?.previewUrl) URL.revokeObjectURL(state.extract.previewUrl);
  state.extract = null;
  state.extractImage = null;
  $('extract-file').value = '';
  $('extract-preview-card').hidden = true;
  $('extract-drop').hidden = false;
  $('extract-preview').removeAttribute('src');
}

function clearExtraction() {
  resetExtractImage();
  $('extract-password').value = '';
  $('recovered-message').value = '';
  $('recovered-count').textContent = '0 characters';
  $('recovered-type').textContent = 'Plain text payload';
  $('recovered-card').hidden = true;
  $('extract-empty').hidden = false;
  clearStatus('extract-status');
}

function bytesToBase64(bytes) {
  let binary = '';
  for (let i = 0; i < bytes.length; i += 0x8000) {
    binary += String.fromCharCode(...bytes.subarray(i, i + 0x8000));
  }
  return btoa(binary);
}

function base64ToBytes(value) {
  if (typeof value !== 'string' || value.length > 50_000_000) throw new Error('Invalid encrypted payload.');
  let binary;
  try { binary = atob(value); } catch { throw new Error('Invalid encrypted payload encoding.'); }
  const bytes = new Uint8Array(binary.length);
  for (let i = 0; i < binary.length; i++) bytes[i] = binary.charCodeAt(i);
  return bytes;
}

async function deriveKey(password, salt) {
  const material = await crypto.subtle.importKey(
    'raw', new TextEncoder().encode(password), 'PBKDF2', false, ['deriveKey']
  );
  return crypto.subtle.deriveKey(
    { name: 'PBKDF2', salt, iterations: PBKDF2_ITERATIONS, hash: 'SHA-256' },
    material,
    { name: 'AES-GCM', length: 256 },
    false,
    ['encrypt', 'decrypt']
  );
}

async function encryptMessage(message, password) {
  if (!crypto?.subtle) throw new Error('Web Crypto is unavailable. Use a modern browser on HTTPS or localhost.');
  const salt = crypto.getRandomValues(new Uint8Array(16));
  const iv = crypto.getRandomValues(new Uint8Array(12));
  const key = await deriveKey(password, salt);
  const plaintext = new TextEncoder().encode(message);
  const ciphertext = await crypto.subtle.encrypt({ name: 'AES-GCM', iv }, key, plaintext);
  const payload = {
    v: 1, kdf: 'PBKDF2-SHA-256', iter: PBKDF2_ITERATIONS, cipher: 'AES-256-GCM',
    salt: bytesToBase64(salt), iv: bytesToBase64(iv), ct: bytesToBase64(new Uint8Array(ciphertext))
  };
  return new TextEncoder().encode(JSON.stringify(payload));
}

async function decryptMessage(payloadBytes, password) {
  if (!password) throw new Error('This message is encrypted. Enter the decryption password.');
  if (!crypto?.subtle) throw new Error('Web Crypto is unavailable. Use a modern browser on HTTPS or localhost.');
  let payload;
  try { payload = JSON.parse(new TextDecoder('utf-8', { fatal: true }).decode(payloadBytes)); }
  catch { throw new Error('The encrypted payload is damaged or has an invalid format.'); }
  if (payload?.v !== 1 || payload?.cipher !== 'AES-256-GCM' || payload?.kdf !== 'PBKDF2-SHA-256' ||
      payload?.iter !== PBKDF2_ITERATIONS) {
    throw new Error('This encrypted payload format is not supported.');
  }
  try {
    const salt = base64ToBytes(payload.salt);
    const iv = base64ToBytes(payload.iv);
    const ciphertext = base64ToBytes(payload.ct);
    if (salt.length !== 16 || iv.length !== 12 || ciphertext.length < 16) throw new Error('Invalid cryptographic parameters.');
    const key = await deriveKey(password, salt);
    const plaintext = await crypto.subtle.decrypt({ name: 'AES-GCM', iv }, key, ciphertext);
    return new TextDecoder('utf-8', { fatal: true }).decode(plaintext);
  } catch {
    throw new Error('Could not decrypt the message. The password may be incorrect or the image data may be damaged.');
  }
}

function makeHeader(payloadLength, encrypted) {
  const header = new Uint8Array(HEADER_BYTES);
  header.set(MAGIC, 0);
  header[4] = FORMAT_VERSION;
  header[5] = encrypted ? 1 : 0;
  new DataView(header.buffer).setUint32(6, payloadLength, false);
  return header;
}

function encodeLSB(imageData, payloadBytes, encrypted) {
  const data = imageData.data;
  const fullLength = HEADER_BYTES + payloadBytes.length;
  const availableBits = imageData.width * imageData.height * 3;
  if (fullLength * 8 > availableBits) {
    throw new Error(`Image capacity exceeded. This image can hold about ${formatBytes(maxPayloadBytes(imageData.width, imageData.height))} of payload, but your message needs ${formatBytes(payloadBytes.length)} plus the header. Choose a larger image or a shorter message.`);
  }
  const header = makeHeader(payloadBytes.length, encrypted);
  const allBytes = new Uint8Array(fullLength);
  allBytes.set(header);
  allBytes.set(payloadBytes, HEADER_BYTES);
  let bitIndex = 0;
  for (let i = 0; i < allBytes.length; i++) {
    for (let shift = 7; shift >= 0; shift--) {
      const pixelChannel = Math.floor(bitIndex / 3) * 4 + (bitIndex % 3);
      const bit = (allBytes[i] >> shift) & 1;
      data[pixelChannel] = (data[pixelChannel] & 0xFE) | bit;
      bitIndex++;
    }
  }
}

function readLSBBytes(imageData, byteCount) {
  const data = imageData.data;
  if (byteCount < 0 || byteCount * 8 > imageData.width * imageData.height * 3) {
    throw new Error('The image contains an invalid payload length or incomplete data.');
  }
  const result = new Uint8Array(byteCount);
  let bitIndex = 0;
  for (let i = 0; i < byteCount; i++) {
    let value = 0;
    for (let shift = 7; shift >= 0; shift--) {
      const pixelChannel = Math.floor(bitIndex / 3) * 4 + (bitIndex % 3);
      value = (value << 1) | (data[pixelChannel] & 1);
      bitIndex++;
    }
    result[i] = value;
  }
  return result;
}

function decodeLSB(imageData) {
  const header = readLSBBytes(imageData, HEADER_BYTES);
  if (!MAGIC.every((byte, index) => header[index] === byte)) {
    throw new Error('No StegoSafe payload was found in this image.');
  }
  if (header[4] !== FORMAT_VERSION) throw new Error('This StegoSafe payload version is not supported.');
  if ((header[5] & 0xFE) !== 0) throw new Error('The payload contains unsupported flags.');
  const length = new DataView(header.buffer, header.byteOffset, header.byteLength).getUint32(6, false);
  if (length > imageData.width * imageData.height * 3 / 8 - HEADER_BYTES) {
    throw new Error('The embedded payload length is invalid. The image may be corrupted.');
  }
  const payload = readLSBBytes(imageData, HEADER_BYTES + length).slice(HEADER_BYTES);
  return { encrypted: (header[5] & 1) === 1, payload };
}

async function hideMessage() {
  clearStatus('hide-status');
  const button = $('hide-button');
  if (!state.cover) return setStatus('hide-status', 'Choose a cover image before encoding.', 'error');
  const message = $('secret-message').value;
  if (!message.length) return setStatus('hide-status', 'Enter a message to hide.', 'error');
  const password = $('hide-password').value;
  setBusy(button, true, 'Encoding image…');
  try {
    await new Promise(resolve => requestAnimationFrame(resolve));
    const plainBytes = new TextEncoder().encode(message);
    const payload = password ? await encryptMessage(message, password) : plainBytes;
    const { canvas, context, imageData } = canvasFor(state.cover);
    encodeLSB(imageData, payload, Boolean(password));
    context.putImageData(imageData, 0, 0);
    const blob = await new Promise((resolve, reject) => canvas.toBlob(
      result => result ? resolve(result) : reject(new Error('The browser could not generate a PNG image.')),
      'image/png'
    ));
    if (state.outputUrl) URL.revokeObjectURL(state.outputUrl);
    state.outputUrl = URL.createObjectURL(blob);
    $('output-preview').src = state.outputUrl;
    $('download-button').href = state.outputUrl;
    $('download-button').download = `stegosafe-${Date.now()}.png`;
    $('output-details').textContent = `${state.cover.width} × ${state.cover.height} px · ${formatBytes(blob.size)} PNG`;
    $('output-card').hidden = false;
    $('hide-empty').hidden = true;
    const used = (HEADER_BYTES + payload.length) / Math.max(1, state.cover.width * state.cover.height * 3 / 8) * 100;
    $('capacity-bar').style.width = `${Math.min(100, used)}%`;
    $('capacity-label').textContent = `${used.toFixed(2)}% used`;
    setStatus('hide-status', `Success — ${password ? 'encrypted' : 'plain-text'} message embedded. Download the PNG and keep its dimensions unchanged.`, 'success');
  } catch (error) {
    setStatus('hide-status', error.message || 'Could not encode the message.', 'error');
  } finally {
    setBusy(button, false);
  }
}

async function extractMessage() {
  clearStatus('extract-status');
  const button = $('extract-button');
  if (!state.extract) return setStatus('extract-status', 'Choose an image to extract from.', 'error');
  setBusy(button, true, 'Extracting message…');
  try {
    await new Promise(resolve => requestAnimationFrame(resolve));
    const { imageData } = canvasFor(state.extract);
    const decoded = decodeLSB(imageData);
    let message;
    if (decoded.encrypted) {
      message = await decryptMessage(decoded.payload, $('extract-password').value);
    } else {
      try { message = new TextDecoder('utf-8', { fatal: true }).decode(decoded.payload); }
      catch { throw new Error('The recovered text is invalid or the payload is corrupted.'); }
    }
    $('recovered-message').value = message;
    $('recovered-count').textContent = `${message.length.toLocaleString()} characters`;
    $('recovered-type').textContent = decoded.encrypted ? 'Encrypted · AES-256-GCM verified' : 'Plain-text payload';
    $('recovered-card').hidden = false;
    $('extract-empty').hidden = true;
    setStatus('extract-status', 'Message recovered successfully. The content has not been saved or transmitted.', 'success');
  } catch (error) {
    $('recovered-card').hidden = true;
    $('extract-empty').hidden = false;
    setStatus('extract-status', error.message || 'Could not extract a message from this image.', 'error');
  } finally {
    setBusy(button, false);
  }
}

async function acceptImage(file, kind) {
  const statusId = kind === 'cover' ? 'hide-status' : 'extract-status';
  clearStatus(statusId);
  try {
    const data = await loadImageFile(file);
    if (kind === 'cover') {
      if (state.cover?.previewUrl) URL.revokeObjectURL(state.cover.previewUrl);
      state.cover = data;
      showPreview('cover', data);
      $('output-card').hidden = true;
      $('hide-empty').hidden = false;
      updateCapacity();
    } else {
      if (state.extract?.previewUrl) URL.revokeObjectURL(state.extract.previewUrl);
      state.extract = data;
      showPreview('extract', data);
      $('recovered-card').hidden = true;
      $('extract-empty').hidden = false;
    }
  } catch (error) {
    setStatus(statusId, error.message || 'Could not load the selected image.', 'error');
  }
}

document.querySelectorAll('.tab').forEach(tab => {
  tab.addEventListener('click', () => {
    document.querySelectorAll('.tab').forEach(item => {
      const selected = item === tab;
      item.classList.toggle('active', selected);
      item.setAttribute('aria-selected', String(selected));
      item.tabIndex = selected ? 0 : -1;
    });
    document.querySelectorAll('[role="tabpanel"]').forEach(panel => {
      panel.hidden = panel.id !== tab.dataset.panel;
    });
  });
});

$('cover-file').addEventListener('change', event => {
  if (event.target.files?.[0]) acceptImage(event.target.files[0], 'cover');
});
$('extract-file').addEventListener('change', event => {
  if (event.target.files?.[0]) acceptImage(event.target.files[0], 'extract');
});
$('clear-cover').addEventListener('click', resetCover);
$('clear-extract-image').addEventListener('click', () => {
  resetExtractImage();
  $('recovered-card').hidden = true;
  $('extract-empty').hidden = false;
  clearStatus('extract-status');
});
$('clear-extraction').addEventListener('click', clearExtraction);
$('hide-button').addEventListener('click', hideMessage);
$('extract-button').addEventListener('click', extractMessage);
$('secret-message').addEventListener('input', event => {
  $('message-count').textContent = `${event.target.value.length.toLocaleString()} characters`;
});
document.querySelectorAll('.show-password').forEach(button => {
  button.addEventListener('click', () => {
    const input = $(button.dataset.target);
    const showing = input.type === 'text';
    input.type = showing ? 'password' : 'text';
    button.textContent = showing ? 'Show' : 'Hide';
    button.setAttribute('aria-label', showing ? 'Show password' : 'Hide password');
  });
});
$('copy-message').addEventListener('click', async () => {
  const button = $('copy-message');
  try {
    await navigator.clipboard.writeText($('recovered-message').value);
    button.textContent = 'Copied!';
    setTimeout(() => { button.textContent = 'Copy text'; }, 1500);
  } catch {
    $('recovered-message').focus();
    $('recovered-message').select();
    setStatus('extract-status', 'Clipboard access is unavailable; the message is selected so you can copy it manually.', 'info');
  }
});

function configureDropZone(zoneId, kind) {
  const zone = $(zoneId);
  ['dragenter', 'dragover'].forEach(type => zone.addEventListener(type, event => {
    event.preventDefault();
    zone.classList.add('drag-over');
  }));
  ['dragleave', 'drop'].forEach(type => zone.addEventListener(type, event => {
    event.preventDefault();
    zone.classList.remove('drag-over');
  }));
  zone.addEventListener('drop', event => {
    const file = event.dataTransfer?.files?.[0];
    if (file) acceptImage(file, kind);
  });
}
configureDropZone('cover-drop', 'cover');
configureDropZone('extract-drop', 'extract');

// Keep a clear keyboard tab order while the inactive panel is hidden.
$('extract-tab').tabIndex = -1;
