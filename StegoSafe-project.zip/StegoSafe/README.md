# StegoSafe — Secure Image Steganography & Message Recovery

**Project by Adnan Nowshad**

StegoSafe is a client-side educational cybersecurity application built with HTML5, CSS3, vanilla JavaScript, Canvas, the File API, Blob downloads, and the Web Crypto API. It hides text in image RGB least-significant bits (LSBs) and recovers it from compatible generated images. No server or third-party API is used to process images, messages, or passwords.

## Run locally

1. Keep `index.html`, `style.css`, and `script.js` in the same folder.
2. Open the folder with a local development server (recommended), for example VS Code's Live Server.
3. Alternatively, open `index.html` directly. Web Crypto is restricted in some browsers on non-secure origins; use `localhost` or HTTPS for encryption.
4. Choose **Hide Message**, select a cover image, enter text, and optionally enter an encryption password.
5. Click **Hide message in image**, then download the PNG.
6. Select **Extract Message**, upload the generated PNG, and provide the password if the payload was encrypted.

No build step or package installation is required.

## Features

- Responsive dark cybersecurity-themed UI.
- PNG, JPEG, WEBP, and BMP image inputs, decoded by the browser.
- Local image previews, dimensions, file-size information, and approximate capacity display.
- RGB-channel LSB encoding; alpha values are preserved by the encoder.
- Capacity checks before embedding.
- PNG export, compatible extraction, and plain/encrypted payload flag.
- Optional AES-256-GCM encryption with a random 128-bit salt and random 96-bit IV.
- PBKDF2 using SHA-256 and 310,000 iterations to derive the AES key.
- Input validation, status messages, loading states, clear controls, and copy recovered text.
- No use of `localStorage`; the app does not send data to a server.

## LSB algorithm

StegoSafe converts the header and payload to bytes and writes each byte most-significant-bit first. For every bit, it visits the next channel in the sequence **R, G, B**, then advances to the next pixel. The channel's least significant bit is replaced with the message bit:

`newChannel = (oldChannel & 0xFE) | messageBit`

The alpha channel is skipped. The decoder visits channels in the exact same order and reconstructs each byte from eight bits.

The output starts with a 10-byte header:

| Offset | Length | Meaning |
|---|---:|---|
| 0 | 4 bytes | ASCII magic `SSAF` |
| 4 | 1 byte | Format version (`1`) |
| 5 | 1 byte | Flags; bit 0 set means encrypted |
| 6 | 4 bytes | Payload length as unsigned big-endian uint32 |
| 10 | variable | Payload bytes |

Capacity is approximately `floor(width × height × 3 / 8) - 10` bytes. The header itself is included in the total encoded bit count. The app rejects payloads that exceed image capacity.

## Encryption format and security notes

When a non-empty password is supplied, the UTF-8 message is encrypted before embedding using **AES-256-GCM** through `crypto.subtle`. The AES key is derived from the password with **PBKDF2-HMAC-SHA-256**, 310,000 iterations, and a fresh random 16-byte salt. Each encryption uses a fresh random 12-byte IV.

The encrypted payload is UTF-8 JSON with these fields:

- `v`: payload schema version (`1`)
- `kdf`: `PBKDF2-SHA-256`
- `iter`: `310000`
- `cipher`: `AES-256-GCM`
- `salt`: base64 salt
- `iv`: base64 IV
- `ct`: base64 ciphertext, including the GCM authentication tag

AES-GCM authenticates ciphertext; a wrong password or tampered ciphertext should fail authentication. This does not make steganography undetectable, nor does it prevent an attacker from detecting that an image may contain hidden data. Password strength matters. A weak password may be guessed offline by someone who obtains the encoded image.

The password and secret message are not written to localStorage and are not sent over the network by this app. Browser extensions, malware, screenshots, or a compromised device remain outside the app's protection.

## Image compatibility and limitations

- Always use the downloaded PNG for extraction. PNG is lossless and preserves the modified RGB values.
- JPEG is supported as an **input cover** because the browser decodes it to pixels before encoding. The generated output is still PNG.
- Resizing, recompressing, editing, color correction, or converting the output to JPEG can change LSBs and destroy the payload.
- This app does not resize images automatically. Images over 24 million pixels are rejected to limit browser memory usage.
- Browser decoding and color management can vary. Use the exact generated PNG and compatible modern browsers for best results.
- LSB steganography is not a substitute for secure file transfer. It hides data in pixels but does not guarantee resistance to steganalysis.
- The UI's capacity figure is an estimate of maximum payload bytes; encryption JSON and authentication-tag overhead mean encrypted messages take more space than their plaintext.
- The implementation targets modern browsers with Canvas, `TextEncoder`/`TextDecoder`, `Blob`, and Web Crypto support.

## Testing checklist

Test with a modern browser and local server:

1. Hide a short plain-text message in a valid PNG, download it, then upload that PNG to Extract Message.
2. Repeat using a JPEG cover; verify the output download is PNG and extraction works from that output.
3. Hide an encrypted message and recover it with the correct password.
4. Attempt decryption with a wrong password; expect a safe failure message.
5. Try an image with no StegoSafe payload; expect “No StegoSafe payload was found”.
6. Use a very small image or a long message; expect a capacity error.
7. Try unsupported files and corrupt image files; expect validation errors.
8. Clear the extraction panel; confirm the selected image, password, recovered text, and status are reset.
9. Refresh the browser, then upload a previously downloaded generated PNG; extraction should still work because the payload is stored in the image, not browser storage.
10. Resize or recompress an encoded PNG and try extraction; recovery may fail, as documented.
11. Test encrypted and unencrypted messages containing Unicode text and newlines.

The source has been reviewed for the core encode/decode flow, but run these checks in your target browsers before using the project for coursework or demonstrations.
